import { type ReactNode } from "react";
import type { ButtonClickLike } from "../../src/ui/buttonActivate";
export type NavigationOptions = {
    replace?: boolean;
};
/** Supplied by the embedding application; this module owns no router or session. */
export interface NavigationAdapter {
    navigate: (href: string, options?: NavigationOptions) => void;
    /** Visible/copyable URL. Callback-only frames use "#" to retain anchor keyboard semantics. */
    href: (href: string) => string;
    /** Only a host with usable URLs should permit browser modified-click navigation. */
    modifiedClicks: "browser" | "prevent";
}
export declare function NavigationProvider({ adapter, children }: {
    adapter: NavigationAdapter;
    children: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
export declare function useNavigation(): NavigationAdapter | null;
export declare function activateNavigation(adapter: NavigationAdapter | null, href: string, event: ButtonClickLike, options?: NavigationOptions): void;
