import type React from "react";
/** A modal confirm: the operator's typed `expect` must equal
 *  `match` before `confirmLabel` enables. Esc cancels, the input
 *  autofocuses and a submit re-arms only through a fresh open. */
export default function ConfirmDialog({ title, body, expect, match, inputLabel, confirmLabel, pending, error, onConfirm, onCancel, }: {
    title: string;
    body: React.ReactNode;
    /** When set, the input gate: confirm enables only when the typed
     *  text equals `match` exactly. */
    expect?: string;
    match?: string;
    inputLabel?: string;
    confirmLabel: string;
    pending: boolean;
    error: string | null;
    onConfirm: () => void;
    onCancel: () => void;
}): import("react/jsx-runtime").JSX.Element;
