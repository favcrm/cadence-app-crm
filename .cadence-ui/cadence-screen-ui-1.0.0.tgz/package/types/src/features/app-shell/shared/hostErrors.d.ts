/**
 * The one error-to-message layer every CRM list shares (CAD-1009).
 * A hosted session that expired answers a records fetch with a 401 and
 * a cross-origin redirect to the authorize URL, which `fetch` cannot
 * follow: it throws a bare TypeError (or a non-Error object). Those all
 * read as one human sentence, and the notice offers a reload — a
 * top-level navigation re-authenticates. A message is always a string:
 * an object is never stringified.
 */
export declare const SESSION_EXPIRED_TEXT = "Your session expired or the connection dropped \u2014 reload the page to sign in again.";
export declare function isGenericRefusal(error: unknown): boolean;
export declare function hostErrorText(error: unknown, fallback: string): string;
