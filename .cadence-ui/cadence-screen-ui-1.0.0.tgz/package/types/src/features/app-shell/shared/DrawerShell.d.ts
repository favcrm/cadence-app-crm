import { type ReactNode } from "react";
/**
 * CAD-1052 one reusable detail-drawer shell for the CRM customer and
 * segment drawers. Layout contract (the clickable mockup is the spec):
 *  - header: avatar/icon, title, subtitle, status pills/tags, an optional
 *    warning strip (text only, never a button) and the tab strip;
 *  - body: the active tab panel, or `edit.body` swapped in place;
 *  - footer: pinned. Every action lives here — the ⋯ menu on the left
 *    (opens upward, destructive item last and red), secondary buttons,
 *    one primary on the right. While editing it becomes Cancel / Save.
 * The scrim dims the outlet only: the left chat pane stays usable.
 * `scrim="board"` (CAD-1216, the Home review drawer) is opt-in: the scrim
 * covers the whole board, a `kicker` sits above the title and `foot`
 * replaces the footer's slots; phones get a bottom sheet.
 * Escape closes an open menu first, then cancels an edit, then the
 * drawer; focus returns through `useDrawerClose`.
 */
export type DrawerTab = {
    id: string;
    label: string;
    panel: ReactNode;
};
export type DrawerMenuItem = {
    key: string;
    label: string;
    onSelect: () => void;
    destructive?: boolean;
    disabled?: boolean;
    title?: string;
};
export type DrawerEdit = {
    /** `id` of the `<form>` in `body`; the footer Save submits it. */
    formId: string;
    title: string;
    body: ReactNode;
    saveLabel?: string;
    pending?: boolean;
    onCancel: () => void;
};
export interface DrawerShellProps {
    kind: string;
    label: string;
    /** Small accent line above the title (board scrim). */
    kicker?: ReactNode;
    /** `board` dims the whole board, not only the outlet. Default `outlet`. */
    scrim?: "outlet" | "board";
    title: string;
    subtitle?: ReactNode;
    avatar?: ReactNode;
    pills?: ReactNode;
    /** Plain warning copy; rendered as a strip with no controls. */
    warning?: ReactNode;
    tabs: DrawerTab[];
    /** Optional controlled tab (so a body link can switch tabs). */
    tab?: string;
    onTab?: (id: string) => void;
    /** Replaces the tabs and body while set; footer becomes Cancel / Save. */
    edit?: DrawerEdit | null;
    /** Loading / error content shown instead of the tabs; the footer hides. */
    state?: ReactNode;
    menu?: DrawerMenuItem[];
    secondary?: ReactNode;
    primary?: ReactNode;
    /** Footer text when the viewer has no actions (read-only view). */
    note?: ReactNode;
    /** Replaces the footer's menu / note / secondary / primary slots. */
    foot?: ReactNode;
    onClose: () => void;
    /** Frame-local scrim edge. When supplied, no host outlet is measured. */
    geometry?: {
        left: number;
    };
}
export default function DrawerShell(props: DrawerShellProps): import("react/jsx-runtime").JSX.Element;
