import type { ReactNode } from "react";
/**
 * Shared semantic data table (CAD-866): the `<table>`-in-a-scrollable-
 * region shape that the CRM record list and the app-views/v1 table
 * preview both hand-rolled.
 *
 * The contract is accessibility + overflow, not styling novelty:
 *  - Real `<thead>`/`<th scope="col">` column headers, `<tbody>` rows.
 *  - The wrapper is a focusable `role="region"` (`tabIndex={0}`) so a
 *    keyboard user can scroll a table that overflows at narrow widths;
 *    its `aria-label` tells them why the region exists.
 *  - `overflow-wrap: anywhere` + a `min-width` floor come from the
 *    shared `.stable`/`.stable-wrap` CSS, so long tokens wrap and the
 *    *wrapper* scrolls — the document never grows past the viewport.
 *
 * Sorting, search, selection and paging stay with the caller: this
 * component renders rows and columns; the semantics of a click or a
 * committed query are the consumer's, unchanged.
 */
export interface DataTableColumn<Row> {
    /** Stable key (field id). Used for React keys, never rendered raw. */
    key: string;
    /** Column header content. */
    header: ReactNode;
    /** Header content is a plain string for `scope="col"` labelling only. */
    cell: (row: Row, index: number) => ReactNode;
    /** Extra class on every `td` of this column. */
    cellClassName?: string;
}
export interface DataTableProps<Row> {
    columns: DataTableColumn<Row>[];
    rows: Row[];
    /** Stable React key for a row (record id, row number). */
    rowKey: (row: Row, index: number) => string | number;
    /** Accessible name for the scrollable region (e.g. "Customers table"). */
    label: string;
    /** Extra class on the scroll wrapper (e.g. a consumer's `crm-table-wrap`). */
    wrapClassName?: string;
    /** Extra class on the `<table>` (e.g. `crm-table` for its width floor). */
    tableClassName?: string;
    /** Optional per-row attributes (e.g. a `data-*` marker). */
    rowProps?: (row: Row, index: number) => Record<string, unknown>;
}
export default function DataTable<Row>({ columns, rows, rowKey, label, wrapClassName, tableClassName, rowProps, }: DataTableProps<Row>): import("react/jsx-runtime").JSX.Element;
