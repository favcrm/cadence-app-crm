import { type TransitionEvent } from "react";
/**
 * CAD-1013 coordinated drawer close. The CRM detail drawer mounts
 * directly on the owning list's selection (`{id !== null && <Drawer
 * onClose={() => onSelect(null)} />}`). To animate close as well as
 * open without restructuring each owner, the drawer marks itself
 * `data-closing`, lets the CSS exit transition run, then calls the
 * real `onClose` when it ends. Reduced-motion and browsers that skip
 * the transition fall back to closing on a timer, so the drawer can
 * never stick open. Single instance and draft are untouched — this
 * only delays the unmount by one transition.
 */
export declare function useDrawerClose(onClose: () => void): {
    closing: boolean;
    requestClose: () => void;
    onTransitionEnd: (e: TransitionEvent) => void;
};
