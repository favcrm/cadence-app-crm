import type { ReactNode } from "react";
/**
 * Shared record/form state blocks (CAD-866): the loading, error,
 * empty and read-only/notice surfaces every host app view repeats.
 * They exist so the accessible roles and the canonical tokens live in
 * exactly one place instead of being re-typed per screen.
 *
 * Live-region urgency follows modern-web-guidance:
 *  - `Loading`/`EmptyState` are `role="status"` (polite) — the screen
 *    reader is told the outcome at the next graceful break.
 *  - `ErrorNotice` is `role="alert"` (assertive) — a refusal that blocks
 *    the operator interrupts immediately.
 *  - `Notice` is a neutral bordered card — read-only/sign-in/context
 *    hints are plain content, announced only when reached.
 *
 * Every block is text-first and colour-independent — the message itself
 * carries the state, the chip/border colour only reinforces it.
 */
/** A neutral bordered notice card (read-only, sign-in, pick-a-context). */
export declare function Notice({ children, className, state, onRetry, retryLabel, }: {
    children: ReactNode;
    className?: string;
    /** Optional `data-state` marker (e.g. "read-only") for tests/QA. */
    state?: string;
    /** CAD-1193: an unavailable access check offers a bounded retry of
     *  the real check — wired by the caller, never a reload. */
    onRetry?: () => void;
    retryLabel?: ReactNode;
}): import("react/jsx-runtime").JSX.Element;
/** A polite busy line — "Reading customers…". */
export declare function Loading({ children, className }: {
    children: ReactNode;
    className?: string;
}): import("react/jsx-runtime").JSX.Element;
/**
 * A refusal message. `role="alert"` announces it; `onRetry` renders an
 * inline text-button Retry when the underlying call can be repeated.
 * The default is a bordered card; `bare` drops the card chrome for an
 * inline form-level error that sits inside an already-carded form.
 */
export declare function ErrorNotice({ children, onRetry, retryLabel, bare, className, }: {
    children: ReactNode;
    onRetry?: () => void;
    retryLabel?: ReactNode;
    /** Inline form errors drop the card border/padding. */
    bare?: boolean;
    className?: string;
}): import("react/jsx-runtime").JSX.Element;
/**
 * The empty-record card. `title` is the bolded line; `children` is the
 * supporting explanation. `name` sets `data-empty` for tests/QA.
 */
export declare function EmptyState({ title, children, name, className, }: {
    title: ReactNode;
    children?: ReactNode;
    /** `data-empty` marker (e.g. "customers") for tests/QA. */
    name?: string;
    className?: string;
}): import("react/jsx-runtime").JSX.Element;
