/**
 * Generic stores for caller-owned resource fetches.
 *
 * Every screen reads the same shape, so "loading", "failed" and "empty"
 * mean the same thing everywhere:
 *
 * - `loading` — nothing has loaded yet and a request is in flight (a
 *   retry after a failure is a load again, not a failure).
 * - `ok` / `empty` — the last request succeeded; `empty` when the payload
 *   has no rows.
 * - `stale` — a refresh failed after an earlier success. The last good
 *   payload stays in `data`; `error` says why the refresh failed.
 * - `failed` — the request failed and nothing has ever loaded.
 *
 * Requests coalesce per resource: `refresh()` while one is in flight joins
 * it, and `invalidate()` (a change notification) while one is in flight
 * schedules exactly one trailing request, because the in-flight one may
 * have been answered from before the change.
 *
 * Stale-while-revalidate: `revalidate()` is what a screen calls when it
 * comes on screen. Loaded data stays visible while the refetch runs, and
 * data younger than `freshMs` is not refetched at all — so returning to a
 * slow screen (`/api/overview` takes seconds) paints at once.
 *
 * Local writes win over older fetches: `write` and `mutate` bump the
 * store's generation, and a request started before the bump is dropped
 * when it lands (with one trailing request queued) — so a drawer save or
 * a stream frame is never reverted by a fetch that predates it.
 *
 * `QueryCache` keys the stores: `cache.resource(key, fetcher)` hands every
 * caller of one key the same store, so two components asking for the same
 * key share one request and one state.
 *
 * No React here — `useResource` adapts a store to a component — so the
 * state machine is unit-tested in plain node (see tests/cache.test.ts).
 */
export type ResourceStatus = "loading" | "ok" | "stale" | "failed" | "empty";
export interface ResourceState<T> {
    data: T | null;
    status: ResourceStatus;
    /** The last request's failure, kept while `stale` or `failed`. */
    error: string | null;
    /** Epoch ms of the last successful load. */
    asOf: number | null;
    /** A request is in flight (also true behind `ok`/`stale` rows). */
    inFlight: boolean;
}
export interface ResourceOptions<T> {
    /** A successful payload with nothing to show — status `empty`. */
    isEmpty?: (data: T) => boolean;
    /** How long a successful load counts as fresh for `revalidate()`. */
    freshMs?: number;
    /** Protected resources can discard observations on an access refusal. */
    discardOnError?: (error: unknown) => boolean;
    now?: () => number;
}
export declare class Resource<T> {
    private readonly readsAllowed;
    private state;
    private inflight;
    private trailing;
    /** Bumped by every local write; a fetch from an older one is dropped. */
    private generation;
    /** Access-boundary epoch: old requests cannot repopulate a paused/reset store. */
    private epoch;
    /** Invalidated while nobody watched: the next `revalidate` fetches. */
    private invalid;
    private readonly listeners;
    private readonly fetcher;
    private readonly isEmpty;
    private readonly freshMs;
    private readonly discardOnError;
    private readonly now;
    constructor(fetcher: () => Promise<T>, opts?: ResourceOptions<T>, readsAllowed?: () => boolean);
    /** Current snapshot. The object is replaced on every change. */
    get: () => ResourceState<T>;
    subscribe: (listener: () => void) => (() => void);
    /** Whether any component is subscribed. */
    observed: () => boolean;
    /** Fetch now, or join the request already in flight. */
    refresh: () => Promise<void>;
    /**
     * An explicit request variant, through the same state/error lifecycle.
     * The fetcher applies only to this run; revalidation and trailing loads
     * keep the default fetcher. Joins any request already in flight.
     */
    refreshUsing: (fetcher: () => Promise<T>) => Promise<void>;
    /**
     * The data changed on the server but nobody is looking: fetch on the
     * next `revalidate` (when a screen shows it) instead of now.
     */
    markInvalid: () => void;
    /**
     * The data changed on the server. Fetch now; if a request is already in
     * flight it may predate the change, so queue one trailing request
     * (never more than one).
     */
    invalidate: () => Promise<void>;
    /**
     * Stale-while-revalidate: fetch unless the last success is younger than
     * `freshMs`. Joins a request in flight; never blanks loaded data.
     */
    revalidate: () => Promise<void>;
    /**
     * Replace the data from outside a fetch — a stream frame or a write
     * response that carries the whole value. Unlike `mutate` it also works
     * before the first load, and it counts as a fresh success.
     */
    write: (fn: (data: T | null) => T) => void;
    /**
     * Apply an authoritative local change (a write response) to loaded data.
     * A no-op before the first load — the next fetch brings it.
     */
    mutate: (fn: (data: T) => T) => void;
    /** Stop trailing work without throwing away same-session observations. */
    pause: () => void;
    /** Clear private observations while keeping shared resource handles valid. */
    reset: () => void;
    private set;
}
/**
 * Keyed stores: one `Resource` per key, created on first use and shared by
 * every later caller. The fetcher and options of the first call win — a key
 * names one server resource, so later callers would pass the same ones.
 */
export declare class QueryCache {
    protected readonly entries: Map<string, Resource<unknown>>;
    /** Family keys — per-argument stores that may be evicted when idle. */
    private readonly evictable;
    private readonly maxIdle;
    /** `maxIdle`: family stores kept while nobody subscribes (oldest go first). */
    constructor(opts?: {
        maxIdle?: number;
    });
    protected createResource<T>(fetcher: () => Promise<T>, opts?: ResourceOptions<T>): Resource<T>;
    resource<T>(key: string, fetcher: () => Promise<T>, opts?: ResourceOptions<T>): Resource<T>;
    /** A family of keys under one prefix: `family("issue", api.issue)("CAD-1")`. */
    family<A extends string, T>(prefix: string, fetcher: (arg: A) => Promise<T>, opts?: ResourceOptions<T>): (arg: A) => Resource<T>;
    /** The store for `key` if anything created it, else null. */
    peek<T>(key: string): Resource<T> | null;
    /**
     * The data behind `key` (or every `key:…` family member) changed. Stores
     * a component is subscribed to refetch now; the others are only marked,
     * and refetch when a screen revalidates them — so invalidating a family
     * costs one request per store on screen, not one per id ever loaded.
     */
    invalidate(key: string): void;
    /** Drop the least recently used idle family stores beyond `maxIdle`. */
    private evict;
}
