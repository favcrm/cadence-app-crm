export declare const LocaleTextProvider: import("react").Provider<((english: string) => string) | null>;
export declare function useTranslate(): (english: string) => string;
