import type { IssueCard } from "./types";
/** DTO-only error shared with screens; no transport, session or API singleton. */
export declare class ApiError extends Error {
    status: number;
    conflict?: string;
    check?: string;
    code?: string;
    revision?: number | null;
    card?: IssueCard;
    constructor(message: string, status: number, opts?: {
        conflict?: string;
        check?: string;
        code?: string;
        revision?: number | null;
        card?: IssueCard;
    });
}
