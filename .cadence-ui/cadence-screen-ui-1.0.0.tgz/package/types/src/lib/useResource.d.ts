import type { Resource, ResourceState } from "./cache";
/** Subscribe a component to one resource store. */
export declare function useResource<T>(resource: Resource<T>): ResourceState<T>;
/**
 * Subscribe and revalidate on mount (stale-while-revalidate): the screen
 * paints whatever the store holds now — loading, or the last payload — and
 * the store refetches behind it unless its data is still fresh.
 */
export declare function useQuery<T>(resource: Resource<T>): ResourceState<T>;
/** `useResource` for a store that may not exist (no drawer open). */
export declare function useMaybeResource<T>(resource: Resource<T> | null): ResourceState<T> | null;
