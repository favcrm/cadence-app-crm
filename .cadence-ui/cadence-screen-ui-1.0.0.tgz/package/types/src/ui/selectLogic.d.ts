/** Pure listbox behaviour for the Select primitive. The component is a thin view over this. */
export type SelectOption = {
    value: string;
    label: string;
    hint?: string;
    badge?: string;
    disabled?: boolean;
    group?: string;
};
/** A search field appears on its own once the list is longer than this. */
export declare const SEARCH_THRESHOLD = 8;
export declare const TYPEAHEAD_MS = 500;
export type SelectModel = {
    open: boolean;
    /** Index into the filtered list. -1 when nothing is highlighted. */
    active: number;
    query: string;
    buffer: string;
    bufferAt: number;
};
export type KeyMods = {
    meta?: boolean;
    ctrl?: boolean;
    alt?: boolean;
};
export type KeyResult = {
    model: SelectModel;
    /** A value to commit, or null when the key did not pick. */
    pick: string | null;
    prevent: boolean;
};
export declare function closedSelect(): SelectModel;
export declare function showsSearch(options: readonly SelectOption[], searchable?: boolean): boolean;
export declare function filterOptions(options: readonly SelectOption[], query: string): SelectOption[];
/** Badge copy is ordinary text — a cost label, not an icon. */
export declare function optionBadgeText(option: SelectOption): string | null;
export declare function enabledIndexes(options: readonly SelectOption[]): number[];
export declare function canPick(option: SelectOption | undefined): option is SelectOption;
export declare function moveActive(options: readonly SelectOption[], active: number, key: "ArrowDown" | "ArrowUp" | "Home" | "End"): number;
/**
 * Typeahead. A single new character starts after `from` and wraps. Extra
 * characters inside the timeout extend the prefix and may stay on `from`.
 * A disabled option is never a match. No match leaves `from` alone.
 */
export declare function typeaheadIndex(options: readonly SelectOption[], buffer: string, from: number): number;
export declare function openSelect(options: readonly SelectOption[], value: string): SelectModel;
export declare function reduceSelectKey(model: SelectModel, options: readonly SelectOption[], searchOn: boolean, value: string, key: string, now: number, mods?: KeyMods): KeyResult;
export declare function reduceQuery(model: SelectModel, options: readonly SelectOption[], query: string, value: string): SelectModel;
export declare function reduceOutside(model: SelectModel): SelectModel;
export declare function reducePick(model: SelectModel, option: SelectOption | undefined): KeyResult;
export type Placement = "above" | "below";
/** Flip the popover above the trigger when the viewport bottom cannot hold it. */
export declare function flipPlacement(trigger: {
    top: number;
    bottom: number;
}, popoverHeight: number, viewportHeight: number, gap?: number): Placement;
