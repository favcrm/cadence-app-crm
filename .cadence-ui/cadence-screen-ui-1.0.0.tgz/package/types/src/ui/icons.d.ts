import type { CSSProperties } from "react";
/** What a semantic icon takes: the size (each export has the board's
 *  default) plus the class/style a call site positions it with. */
type IconProps = {
    size?: number;
    className?: string;
    style?: CSSProperties;
};
/** Home — the master chat and the needs-you rail. */
export declare const IconHome: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Projects — the kanban board. */
export declare const IconProjects: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Apps — the installed app bundles. */
export declare const IconApps: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Agents — panes, models and their bound work. */
export declare const IconAgents: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Outbox — published local items. */
export declare const IconOutbox: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Settings — models, memory and the update card. */
export declare const IconSettings: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Wiki — the page store, and a page or file in the tree. */
export declare const IconWiki: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** A folder in the wiki tree and its empty state. */
export declare const IconFolder: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** The disclosure chevron; rotate it for open rows. */
export declare const IconChevron: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Tree disclosure; the row rotates it when the folder is open. */
export declare const IconCaret: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Close a drawer or a panel. */
export declare const IconClose: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** The overflow "more" menu. */
export declare const IconMore: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Search. */
export declare const IconSearch: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** The read-only chip's lock. */
export declare const IconLock: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** The daemon is reachable — a live pulse. */
export declare const IconPulse: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** The daemon is unreachable — a warning. */
export declare const IconWarning: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Re-read the folders. */
export declare const IconRefresh: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Theme: follow the system. */
export declare const IconTheme: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Theme: light. */
export declare const IconSun: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Theme: dark. */
export declare const IconMoon: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Drop files into the wiki. */
export declare const IconUpload: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** A completed upload. */
export declare const IconCheck: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Folder view: grid. */
export declare const IconGrid: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Folder view: list. */
export declare const IconList: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** A newer UI version is available. */
export declare const IconUpdate: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
/** Daemon connection — paired plugs, distinct from activity and refresh. */
export declare const IconConnection: ({ size, ...rest }?: IconProps) => import("react/jsx-runtime").JSX.Element;
export {};
