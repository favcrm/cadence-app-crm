import type { MouseEvent, ReactNode } from "react";
export type ButtonVariant = "primary" | "secondary" | "ghost" | "danger";
export type ButtonSize = "sm" | "md";
export type ButtonProps = {
    /** Visual weight. `secondary` is the bordered default. */
    variant?: ButtonVariant;
    /** `sm` is 1.75rem, `md` is 2rem. Text is centred in that fixed height. */
    size?: ButtonSize;
    /** Stretch to the container width. Label still centres, and overflows with an ellipsis. */
    full?: boolean;
    /** Disables the control and shows a spinner. Clicks do not fire. */
    loading?: boolean;
    icon?: ReactNode;
    disabled?: boolean;
    /**
     * Renders an anchor. A plain left click calls `navigate` (no full reload).
     * Modified clicks keep the browser default so the href can open in a new tab.
     */
    href?: string;
    /** Passed to `navigate` when `href` is set. */
    replace?: boolean;
    /** Ignored when `href` is set. Defaults to `button` so a form is not submitted by accident. */
    type?: "button" | "submit" | "reset";
    title?: string;
    className?: string;
    id?: string;
    children?: ReactNode;
    onClick?: (event: MouseEvent<HTMLButtonElement | HTMLAnchorElement>) => void;
    "aria-label"?: string;
    "aria-pressed"?: boolean | "mixed";
};
/**
 * Shared button. Label text is centred (`justify-content` and `line-height: 1`
 * in `.btn`) so a full-width control does not sit on the left of its box.
 */
export declare function Button(props: ButtonProps): import("react/jsx-runtime").JSX.Element;
export default Button;
