import { type SelectOption } from "./selectLogic";
export type { SelectOption };
export type SelectProps = {
    value: string;
    /** Commits the option's `value` string. */
    onChange: (value: string) => void;
    options: SelectOption[];
    placeholder?: string;
    /** Force the search field. It also appears on its own above 8 options. */
    searchable?: boolean;
    disabled?: boolean;
    id?: string;
    /** `sm` is 1.75rem, `md` is 2rem — the same scale as Button. */
    size?: "sm" | "md";
    full?: boolean;
    className?: string;
    title?: string;
    "aria-label"?: string;
};
/**
 * Select-only combobox: a button trigger plus a portaled listbox.
 * Keyboard: Up/Down/Home/End move, Enter/Space pick, Escape closes,
 * and a typed prefix jumps (unless the search field is showing).
 */
export declare function Select({ value, onChange, options, placeholder, searchable, disabled, id, size, full, className, title, ...rest }: SelectProps): import("react/jsx-runtime").JSX.Element;
export default Select;
