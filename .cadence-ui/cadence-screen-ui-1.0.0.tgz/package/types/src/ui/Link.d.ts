import type { AnchorHTMLAttributes } from "react";
export type LinkProps = AnchorHTMLAttributes<HTMLAnchorElement> & {
    href: string;
    replace?: boolean;
};
/**
 * An in-app link: a real `<a href>` (so it can be opened in a new tab or
 * copied) that navigates through history on a plain left click.
 */
export default function Link({ href, onClick, replace, ...rest }: LinkProps): import("react/jsx-runtime").JSX.Element;
