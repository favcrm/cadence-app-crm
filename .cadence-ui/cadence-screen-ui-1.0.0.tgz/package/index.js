import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { createContext, useCallback, useContext, useEffect, useId, useLayoutEffect, useRef, useState, useSyncExternalStore } from "react";
import { HugeiconsIcon } from "@hugeicons/react";
import { Alert02Icon, ArrowDown01Icon, ArrowRight01Icon, Cancel01Icon, CircleArrowUp01Icon, Comment01Icon, ConnectIcon, ContrastIcon, CubeIcon, DashboardSquare01Icon, File01Icon, Folder01Icon, Home01Icon, KanbanIcon, MailSend01Icon, Menu01Icon, Moon02Icon, MoreHorizontalIcon, Pulse01Icon, RefreshIcon, Robot01Icon, Search01Icon, Settings02Icon, SquareLock01Icon, Sun01Icon, Tick02Icon, Upload01Icon } from "@hugeicons/core-free-icons";
import { createPortal } from "react-dom";
//#region ui/src/features/app-shell/shared/DataTable.tsx
function DataTable({ columns, rows, rowKey, label, wrapClassName, tableClassName, rowProps }) {
	return /* @__PURE__ */ jsx("div", {
		className: ["stable-wrap", wrapClassName ?? ""].filter(Boolean).join(" "),
		tabIndex: 0,
		role: "region",
		"aria-label": label,
		children: /* @__PURE__ */ jsxs("table", {
			className: ["stable", tableClassName ?? ""].filter(Boolean).join(" "),
			children: [/* @__PURE__ */ jsx("thead", { children: /* @__PURE__ */ jsx("tr", { children: columns.map((column) => /* @__PURE__ */ jsx("th", {
				scope: "col",
				children: column.header
			}, column.key)) }) }), /* @__PURE__ */ jsx("tbody", { children: rows.map((row, index) => /* @__PURE__ */ jsx("tr", {
				...rowProps?.(row, index) ?? {},
				children: columns.map((column) => /* @__PURE__ */ jsx("td", {
					className: column.cellClassName,
					children: column.cell(row, index)
				}, column.key))
			}, rowKey(row, index))) })]
		})
	});
}
//#endregion
//#region ui/src/features/app-shell/shared/Field.tsx
function Field(props) {
	const { label, children, id, hint, error, required, disabled, readOnly, className } = props;
	const generated = useId();
	const controlId = id ?? generated;
	const hasError = error !== void 0 && error !== null && error !== "";
	const hintId = hint !== void 0 && hint !== null ? `${controlId}-hint` : void 0;
	const errorId = hasError ? `${controlId}-error` : void 0;
	const control = children({
		id: controlId,
		"aria-describedby": [hintId, errorId].filter(Boolean).join(" ") || void 0,
		"aria-invalid": hasError ? true : void 0,
		required: required || void 0,
		disabled: disabled || void 0,
		readOnly: readOnly || void 0
	});
	return /* @__PURE__ */ jsxs("div", {
		className: ["sfield", className ?? ""].filter(Boolean).join(" "),
		"data-state": disabled ? "disabled" : readOnly ? "read-only" : void 0,
		children: [
			/* @__PURE__ */ jsxs("label", {
				className: "sfield-label text-label text-ink-300",
				htmlFor: controlId,
				children: [label, required ? /* @__PURE__ */ jsxs("span", {
					className: "sfield-req",
					"aria-hidden": "true",
					children: [" ", "*"]
				}) : null]
			}),
			hint !== void 0 && hint !== null ? /* @__PURE__ */ jsx("p", {
				className: "sfield-hint text-micro text-ink-500",
				id: hintId,
				children: hint
			}) : null,
			control,
			hasError ? /* @__PURE__ */ jsx("p", {
				className: "sfield-error text-label text-fail",
				id: errorId,
				role: "alert",
				children: error
			}) : null
		]
	});
}
//#endregion
//#region ui/src/features/app-shell/shared/Detail.tsx
function Detail({ items, label, className }) {
	return /* @__PURE__ */ jsx("dl", {
		className: ["sdetail", className ?? ""].filter(Boolean).join(" "),
		"aria-label": label,
		children: items.map((item) => /* @__PURE__ */ jsxs("div", { children: [/* @__PURE__ */ jsx("dt", { children: item.term }), /* @__PURE__ */ jsx("dd", { children: item.value })] }, item.key))
	});
}
//#endregion
//#region ui/src/ui/buttonActivate.ts
function activateButtonHref(href, event, navigateFn, opts) {
	if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
	event.preventDefault();
	navigateFn(href, opts);
}
//#endregion
//#region ui/screen-ui/src/navigation.tsx
var NavigationContext = createContext(null);
function NavigationProvider({ adapter, children }) {
	return /* @__PURE__ */ jsx(NavigationContext.Provider, {
		value: adapter,
		children
	});
}
function useNavigation() {
	return useContext(NavigationContext);
}
function activateNavigation(adapter, href, event, options) {
	if (event.defaultPrevented) return;
	if (adapter === null || adapter.modifiedClicks === "prevent" && (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)) {
		event.preventDefault();
		return;
	}
	activateButtonHref(href, event, adapter.navigate, options);
}
//#endregion
//#region ui/src/ui/Button.tsx
function buttonClass(props) {
	const variant = props.variant ?? "secondary";
	return [
		"btn",
		variant === "primary" ? "btn-primary" : "",
		variant === "ghost" ? "btn-ghost" : "",
		variant === "danger" ? "btn-danger" : "",
		props.size === "sm" ? "btn-sm" : "",
		props.full ? "btn-full" : "",
		props.className ?? ""
	].filter(Boolean).join(" ");
}
function labelTitle(title, children) {
	if (title) return title;
	return typeof children === "string" && children.trim() ? children : void 0;
}
function ButtonBody({ icon, loading, children }) {
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		loading ? /* @__PURE__ */ jsx("span", {
			className: "btn-spin",
			"aria-hidden": "true"
		}) : null,
		!loading && icon ? /* @__PURE__ */ jsx("span", {
			className: "btn-icon",
			children: icon
		}) : null,
		children != null && children !== false ? /* @__PURE__ */ jsx("span", {
			className: "btn-label",
			children
		}) : null
	] });
}
/**
* Shared button. Label text is centred (`justify-content` and `line-height: 1`
* in `.btn`) so a full-width control does not sit on the left of its box.
*/
function Button(props) {
	const navigation = useNavigation();
	const { disabled, loading, href, replace, type = "button", title, id, children, onClick, icon } = props;
	const inactive = disabled || loading;
	const className = buttonClass(props);
	const tip = labelTitle(title, children);
	const ariaLabel = props["aria-label"];
	if (href) return /* @__PURE__ */ jsx("a", {
		id,
		href: inactive ? void 0 : navigation?.href(href),
		className,
		title: tip,
		"aria-label": ariaLabel,
		"aria-disabled": inactive || void 0,
		"aria-busy": loading || void 0,
		tabIndex: inactive ? -1 : void 0,
		onClick: (event) => {
			onClick?.(event);
			if (inactive) event.preventDefault();
			activateNavigation(navigation, href, event, replace ? { replace: true } : void 0);
		},
		children: /* @__PURE__ */ jsx(ButtonBody, {
			icon,
			loading,
			children
		})
	});
	return /* @__PURE__ */ jsx("button", {
		id,
		type,
		className,
		title: tip,
		"aria-label": ariaLabel,
		"aria-pressed": props["aria-pressed"],
		"aria-busy": loading || void 0,
		disabled: inactive || void 0,
		onClick,
		children: /* @__PURE__ */ jsx(ButtonBody, {
			icon,
			loading,
			children
		})
	});
}
//#endregion
//#region ui/src/lib/localeText.tsx
var LocaleTextContext = createContext(null);
var LocaleTextProvider = LocaleTextContext.Provider;
function useTranslate() {
	return useContext(LocaleTextContext) ?? ((english) => english);
}
//#endregion
//#region ui/src/features/app-shell/shared/useDrawerClose.ts
/**
* CAD-1013 coordinated drawer close. The CRM detail drawer mounts
* directly on the owning list's selection (`{id !== null && <Drawer
* onClose={() => onSelect(null)} />}`). To animate close as well as
* open without restructuring each owner, the drawer marks itself
* `data-closing`, lets the CSS exit transition run, then calls the
* real `onClose` when it ends. Reduced-motion and browsers that skip
* the transition fall back to closing on a timer, so the drawer can
* never stick open. Single instance and draft are untouched — this
* only delays the unmount by one transition.
*/
function useDrawerClose(onClose) {
	const [closing, setClosing] = useState(false);
	const timer = useRef(null);
	const done = useRef(false);
	const opener = useRef(typeof document === "undefined" ? null : document.activeElement);
	const openerRow = useRef(opener.current instanceof Element ? opener.current.closest("[data-record-id]")?.getAttribute("data-record-id") ?? null : null);
	const finish = useCallback(() => {
		if (done.current) return;
		done.current = true;
		onClose();
		window.setTimeout(() => {
			let back = opener.current;
			if (!(back instanceof HTMLElement) || !back.isConnected || back === document.body) {
				const row = openerRow.current;
				back = row === null ? null : Array.from(document.querySelectorAll("[data-record-id]")).find((el) => el.getAttribute("data-record-id") === row)?.querySelector("button, a") ?? null;
			}
			if (back instanceof HTMLElement && back.isConnected) {
				back.focus();
				return;
			}
			const heading = document.querySelector("[data-outlet-heading]");
			if (heading !== null) {
				if (!heading.hasAttribute("tabindex")) heading.setAttribute("tabindex", "-1");
				heading.focus();
			}
		}, 0);
	}, [onClose]);
	const requestClose = useCallback(() => {
		if (closing || done.current) return;
		setClosing(true);
		timer.current = window.setTimeout(finish, 320);
	}, [closing, finish]);
	const onTransitionEnd = useCallback((e) => {
		if (!closing) return;
		if (e.target !== e.currentTarget) return;
		finish();
	}, [closing, finish]);
	useEffect(() => () => {
		if (timer.current !== null) window.clearTimeout(timer.current);
	}, []);
	return {
		closing,
		requestClose,
		onTransitionEnd
	};
}
//#endregion
//#region ui/src/features/app-shell/shared/DrawerShell.tsx
/** Left edge of the outlet, so the scrim never dims the chat pane. */
function useScrimLeft(explicitLeft) {
	const [left, setLeft] = useState(0);
	useLayoutEffect(() => {
		if (explicitLeft !== void 0) return;
		const measure = () => {
			const outlet = document.querySelector(".app-shell-outlet");
			setLeft(outlet !== null && window.innerWidth >= 1024 ? Math.round(outlet.getBoundingClientRect().left) : 0);
		};
		measure();
		window.addEventListener("resize", measure);
		return () => window.removeEventListener("resize", measure);
	}, [explicitLeft]);
	return explicitLeft ?? left;
}
function OverflowMenu({ items, open, setOpen }) {
	const t = useTranslate();
	const wrap = useRef(null);
	const trigger = useRef(null);
	useEffect(() => {
		if (!open) return;
		wrap.current?.querySelector("[role=\"menuitem\"]")?.focus();
		const away = (e) => {
			if (wrap.current && !wrap.current.contains(e.target)) setOpen(false);
		};
		document.addEventListener("mousedown", away);
		return () => document.removeEventListener("mousedown", away);
	}, [open, setOpen]);
	const onKey = (e) => {
		if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
		const els = Array.from(wrap.current?.querySelectorAll("[role=\"menuitem\"]") ?? []);
		const at = els.indexOf(document.activeElement);
		els[e.key === "ArrowDown" ? (at + 1) % els.length : (at - 1 + els.length) % els.length]?.focus();
		e.preventDefault();
	};
	return /* @__PURE__ */ jsxs("div", {
		className: "crm-drawer-menu",
		ref: wrap,
		onKeyDown: onKey,
		children: [/* @__PURE__ */ jsx("button", {
			ref: trigger,
			type: "button",
			className: "btn btn-sm btn-icon",
			"aria-label": t("More actions"),
			"aria-haspopup": "menu",
			"aria-expanded": open,
			onClick: () => setOpen(!open),
			children: "⋯"
		}), open && /* @__PURE__ */ jsx("div", {
			className: "crm-drawer-pop",
			role: "menu",
			"aria-label": t("More actions"),
			children: items.map((item) => /* @__PURE__ */ jsx("button", {
				type: "button",
				role: "menuitem",
				className: item.destructive ? "danger" : void 0,
				"aria-disabled": item.disabled || void 0,
				title: item.title,
				onClick: () => {
					if (item.disabled) return;
					setOpen(false);
					trigger.current?.focus();
					item.onSelect();
				},
				children: item.label
			}, item.key))
		})]
	});
}
function DrawerShell(props) {
	const { kind, label, kicker, scrim = "outlet", title, subtitle, avatar, pills, warning, tabs, tab: tabProp, onTab, edit, state, menu, secondary, primary, note, foot, onClose } = props;
	const headRef = useRef(null);
	const [tabState, setTabState] = useState(tabs[0]?.id ?? "");
	const tab = tabProp ?? tabState;
	const setTab = (id) => {
		setTabState(id);
		onTab?.(id);
	};
	const [menuOpen, setMenuOpen] = useState(false);
	const { closing, requestClose, onTransitionEnd } = useDrawerClose(onClose);
	const t = useTranslate();
	const scrimLeft = useScrimLeft(props.geometry?.left);
	const editing = edit != null;
	useEffect(() => {
		headRef.current?.focus();
	}, []);
	useEffect(() => {
		const onKeyDown = (e) => {
			if (e.key !== "Escape") return;
			if (menuOpen) setMenuOpen(false);
			else if (edit != null) edit.onCancel();
			else requestClose();
		};
		addEventListener("keydown", onKeyDown);
		return () => removeEventListener("keydown", onKeyDown);
	}, [
		menuOpen,
		edit,
		requestClose
	]);
	const active = tabs.find((t) => t.id === tab) ?? tabs[0];
	const onTabKey = (e, index) => {
		if (e.key !== "ArrowRight" && e.key !== "ArrowLeft") return;
		const next = tabs[(index + (e.key === "ArrowRight" ? 1 : tabs.length - 1)) % tabs.length];
		setTab(next.id);
		document.getElementById(`crm-tab-${kind}-${next.id}`)?.focus();
	};
	const hasFooter = state == null && (editing || foot != null || (menu?.length ?? 0) > 0 || secondary != null || primary != null || note != null);
	const board = scrim === "board";
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("div", {
		className: "crm-drawer-scrim",
		style: { left: board ? 0 : scrimLeft },
		"data-scrim": board ? "board" : void 0,
		"data-closing": closing || void 0,
		onClick: requestClose,
		"aria-hidden": "true"
	}), /* @__PURE__ */ jsxs("div", {
		className: "crm-drawer crm-drawer-shell",
		role: "dialog",
		"aria-modal": "false",
		"aria-label": label,
		"data-drawer": kind,
		"data-scrim": board ? "board" : void 0,
		"data-mode": editing ? "edit" : "view",
		"data-closing": closing || void 0,
		onTransitionEnd,
		children: [
			/* @__PURE__ */ jsxs("header", {
				className: "crm-drawer-top",
				children: [
					/* @__PURE__ */ jsxs("div", {
						className: "crm-drawer-id",
						children: [
							avatar != null && /* @__PURE__ */ jsx("span", {
								className: "crm-drawer-avatar",
								"aria-hidden": "true",
								children: avatar
							}),
							/* @__PURE__ */ jsxs("div", {
								className: "crm-drawer-titles",
								children: [
									kicker != null && /* @__PURE__ */ jsx("div", {
										className: "crm-drawer-kicker",
										children: kicker
									}),
									/* @__PURE__ */ jsx("h3", {
										ref: headRef,
										className: "crm-drawer-title",
										tabIndex: -1,
										children: title
									}),
									subtitle != null && /* @__PURE__ */ jsx("div", {
										className: "crm-drawer-sub",
										children: subtitle
									}),
									pills != null && /* @__PURE__ */ jsx("div", {
										className: "crm-drawer-pills",
										children: pills
									})
								]
							}),
							/* @__PURE__ */ jsx("button", {
								type: "button",
								className: "btn btn-sm btn-ghost btn-icon",
								onClick: requestClose,
								"aria-label": `${t("Close")} ${label.toLowerCase()}`,
								children: "✕"
							})
						]
					}),
					warning != null && !editing && state == null && /* @__PURE__ */ jsx("p", {
						className: "crm-drawer-warn",
						"data-testid": "drawer-warning",
						children: warning
					}),
					state == null && !editing && tabs.length > 1 && /* @__PURE__ */ jsx("div", {
						className: "crm-drawer-tabs",
						role: "tablist",
						"aria-label": `${label} ${t("sections")}`,
						children: tabs.map((t, i) => /* @__PURE__ */ jsx("button", {
							id: `crm-tab-${kind}-${t.id}`,
							type: "button",
							role: "tab",
							className: "crm-drawer-tab",
							"aria-selected": active?.id === t.id,
							"aria-controls": `crm-panel-${kind}`,
							tabIndex: active?.id === t.id ? 0 : -1,
							onClick: () => setTab(t.id),
							onKeyDown: (e) => onTabKey(e, i),
							children: t.label
						}, t.id))
					}),
					editing && /* @__PURE__ */ jsx("h4", {
						className: "crm-drawer-edit-title",
						children: edit.title
					})
				]
			}),
			/* @__PURE__ */ jsx("div", {
				className: "crm-drawer-body",
				id: `crm-panel-${kind}`,
				role: state == null && !editing && tabs.length > 1 ? "tabpanel" : void 0,
				"aria-labelledby": state == null && !editing && tabs.length > 1 && active ? `crm-tab-${kind}-${active.id}` : void 0,
				children: state ?? (editing ? edit.body : active?.panel)
			}),
			hasFooter && /* @__PURE__ */ jsx("footer", {
				className: "crm-drawer-foot",
				"data-state": note != null && !editing ? "read-only" : void 0,
				children: editing ? /* @__PURE__ */ jsxs(Fragment, { children: [
					/* @__PURE__ */ jsx("span", { className: "crm-drawer-spacer" }),
					/* @__PURE__ */ jsx(Button, {
						size: "sm",
						variant: "ghost",
						onClick: edit.onCancel,
						disabled: edit.pending,
						children: t("Cancel")
					}),
					/* @__PURE__ */ jsx("button", {
						type: "submit",
						form: edit.formId,
						className: "btn btn-sm btn-primary",
						disabled: edit.pending,
						"aria-busy": edit.pending || void 0,
						children: edit.pending ? t("Saving…") : edit.saveLabel ?? t("Save")
					})
				] }) : foot != null ? foot : /* @__PURE__ */ jsxs(Fragment, { children: [
					menu != null && menu.length > 0 && /* @__PURE__ */ jsx(OverflowMenu, {
						items: menu,
						open: menuOpen,
						setOpen: setMenuOpen
					}),
					note != null && /* @__PURE__ */ jsx("span", {
						className: "crm-drawer-note",
						children: note
					}),
					/* @__PURE__ */ jsx("span", { className: "crm-drawer-spacer" }),
					secondary,
					primary
				] })
			})
		]
	})] });
}
//#endregion
//#region ui/src/lib/apiError.ts
/** DTO-only error shared with screens; no transport, session or API singleton. */
var ApiError = class extends Error {
	status;
	conflict;
	check;
	code;
	revision;
	card;
	constructor(message, status, opts) {
		super(message);
		this.status = status;
		this.conflict = opts?.conflict;
		this.check = opts?.check;
		this.code = opts?.code;
		this.revision = opts?.revision;
		this.card = opts?.card;
	}
};
//#endregion
//#region ui/src/features/app-shell/shared/States.tsx
/**
* Shared record/form state blocks (CAD-866): the loading, error,
* empty and read-only/notice surfaces every host app view repeats.
* They exist so the accessible roles and the canonical tokens live in
* exactly one place instead of being re-typed per screen.
*
* Live-region urgency follows modern-web-guidance:
*  - `Loading`/`EmptyState` are `role="status"` (polite) — the screen
*    reader is told the outcome at the next graceful break.
*  - `ErrorNotice` is `role="alert"` (assertive) — a refusal that blocks
*    the operator interrupts immediately.
*  - `Notice` is a neutral bordered card — read-only/sign-in/context
*    hints are plain content, announced only when reached.
*
* Every block is text-first and colour-independent — the message itself
* carries the state, the chip/border colour only reinforces it.
*/
/** A neutral bordered notice card (read-only, sign-in, pick-a-context). */
function Notice({ children, className, state, onRetry, retryLabel = "Retry" }) {
	return /* @__PURE__ */ jsxs("p", {
		className: [
			"snotice",
			"card",
			"px-4",
			"py-3",
			"text-label",
			"text-ink-400",
			className ?? ""
		].filter(Boolean).join(" "),
		"data-state": state,
		children: [children, onRetry ? /* @__PURE__ */ jsxs(Fragment, { children: [" ", /* @__PURE__ */ jsx("button", {
			type: "button",
			className: "lnk",
			onClick: onRetry,
			children: retryLabel
		})] }) : null]
	});
}
/** A polite busy line — "Reading customers…". */
function Loading({ children, className }) {
	return /* @__PURE__ */ jsx("p", {
		className: [
			"sloading",
			"text-secondary",
			"text-ink-400",
			className ?? ""
		].filter(Boolean).join(" "),
		role: "status",
		children
	});
}
/**
* A refusal message. `role="alert"` announces it; `onRetry` renders an
* inline text-button Retry when the underlying call can be repeated.
* The default is a bordered card; `bare` drops the card chrome for an
* inline form-level error that sits inside an already-carded form.
*/
function ErrorNotice({ children, onRetry, retryLabel = "Retry", bare, className }) {
	const t = useTranslate();
	return /* @__PURE__ */ jsxs("p", {
		className: [
			"serror",
			bare ? "" : "card px-4 py-3 border-fail/40",
			"text-label",
			"text-fail",
			className ?? ""
		].filter(Boolean).join(" "),
		role: "alert",
		children: [children, onRetry || children === "Your session expired or the connection dropped — reload the page to sign in again." ? /* @__PURE__ */ jsxs(Fragment, { children: [" ", children === "Your session expired or the connection dropped — reload the page to sign in again." ? /* @__PURE__ */ jsx("button", {
			type: "button",
			className: "lnk",
			onClick: () => window.location.reload(),
			children: t("Reload")
		}) : /* @__PURE__ */ jsx("button", {
			type: "button",
			className: "lnk",
			onClick: onRetry,
			children: retryLabel
		})] }) : null]
	});
}
/**
* The empty-record card. `title` is the bolded line; `children` is the
* supporting explanation. `name` sets `data-empty` for tests/QA.
*/
function EmptyState({ title, children, name, className }) {
	return /* @__PURE__ */ jsxs("div", {
		className: [
			"sempty",
			"card",
			"px-4",
			"py-5",
			"text-secondary",
			"text-ink-400",
			className ?? ""
		].filter(Boolean).join(" "),
		"data-empty": name,
		role: "status",
		children: [/* @__PURE__ */ jsx("p", {
			className: "font-medium text-ink-200",
			children: title
		}), children !== void 0 && children !== null ? /* @__PURE__ */ jsx("p", {
			className: "mt-1",
			children
		}) : null]
	});
}
//#endregion
//#region ui/src/features/app-shell/shared/ConfirmDialog.tsx
/** A modal confirm: the operator's typed `expect` must equal
*  `match` before `confirmLabel` enables. Esc cancels, the input
*  autofocuses and a submit re-arms only through a fresh open. */
function ConfirmDialog({ title, body, expect, match, inputLabel, confirmLabel, pending, error, onConfirm, onCancel }) {
	const t = useTranslate();
	const [typed, setTyped] = useState("");
	const inputRef = useRef(null);
	useEffect(() => {
		if (expect !== void 0) inputRef.current?.focus();
	}, [expect]);
	const gated = expect !== void 0 ? typed.trim() === (match ?? "") : true;
	return /* @__PURE__ */ jsxs("div", {
		className: "crm-confirm-wrap",
		role: "presentation",
		children: [/* @__PURE__ */ jsx("div", {
			className: "crm-confirm-scrim",
			onClick: onCancel
		}), /* @__PURE__ */ jsxs("section", {
			className: "card crm-confirm grid gap-3",
			role: "dialog",
			"aria-modal": "true",
			"aria-label": title,
			onKeyDown: (e) => {
				if (e.key === "Escape") {
					e.stopPropagation();
					onCancel();
				}
			},
			children: [
				/* @__PURE__ */ jsx("h4", {
					className: "text-cardtitle font-medium text-ink-100",
					children: title
				}),
				/* @__PURE__ */ jsx("div", {
					className: "text-label text-ink-300",
					children: body
				}),
				expect !== void 0 && /* @__PURE__ */ jsxs("div", {
					className: "crm-field",
					children: [/* @__PURE__ */ jsx("label", {
						className: "text-label text-ink-300",
						htmlFor: "crm-confirm-input",
						children: inputLabel ?? `${t("Type")} ${match} ${t("to confirm")}`
					}), /* @__PURE__ */ jsx("input", {
						id: "crm-confirm-input",
						ref: inputRef,
						className: "field num",
						inputMode: "numeric",
						value: typed,
						onChange: (e) => setTyped(e.target.value),
						maxLength: 12,
						autoComplete: "off",
						disabled: pending
					})]
				}),
				error && /* @__PURE__ */ jsx("p", {
					className: "text-label text-fail",
					role: "alert",
					children: error
				}),
				/* @__PURE__ */ jsxs("div", {
					className: "crm-toolbar",
					children: [/* @__PURE__ */ jsx(Button, {
						size: "sm",
						onClick: onCancel,
						disabled: pending,
						children: t("Cancel")
					}), /* @__PURE__ */ jsx(Button, {
						size: "sm",
						variant: "danger",
						loading: pending,
						disabled: pending || !gated,
						onClick: onConfirm,
						children: confirmLabel
					})]
				})
			]
		})]
	});
}
//#endregion
//#region ui/src/ui/Link.tsx
/**
* An in-app link: a real `<a href>` (so it can be opened in a new tab or
* copied) that navigates through history on a plain left click.
*/
function Link({ href, onClick, replace, ...rest }) {
	const navigation = useNavigation();
	const go = (e) => {
		onClick?.(e);
		activateNavigation(navigation, href, e, { replace });
	};
	return /* @__PURE__ */ jsx("a", {
		href: navigation?.href(href),
		onClick: go,
		...rest
	});
}
//#endregion
//#region ui/src/ui/icons.tsx
/** Hugeicons Stroke Rounded — the board's one icon vocabulary, shared
*  with AgenticOS v2 Studio. Every glyph is drawn the same way: 1.7
*  stroke, currentColor, aria-hidden (the label lives on the control),
*  never squashed by flex. Sizes match the inline SVGs they replace. */
function Glyph({ icon, size = 15, className, style }) {
	return /* @__PURE__ */ jsx(HugeiconsIcon, {
		icon,
		size,
		strokeWidth: 1.7,
		color: "currentColor",
		"aria-hidden": "true",
		focusable: "false",
		className,
		style: {
			flexShrink: 0,
			...style
		}
	});
}
/** Home — the master chat and the needs-you rail. */
var IconHome = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Home01Icon,
	size,
	...rest
});
/** Projects — the kanban board. */
var IconProjects = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: KanbanIcon,
	size,
	...rest
});
/** Apps — the installed app bundles. */
var IconApps = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: CubeIcon,
	size,
	...rest
});
/** Agents — panes, models and their bound work. */
var IconAgents = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Robot01Icon,
	size,
	...rest
});
/** Threads — agent, operator and group conversations (CAD-818). */
var IconThreads = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Comment01Icon,
	size,
	...rest
});
/** Outbox — published local items. */
var IconOutbox = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: MailSend01Icon,
	size,
	...rest
});
/** Settings — models, memory and the update card. */
var IconSettings = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Settings02Icon,
	size,
	...rest
});
/** Wiki — the page store, and a page or file in the tree. */
var IconWiki = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: File01Icon,
	size,
	...rest
});
/** A folder in the wiki tree and its empty state. */
var IconFolder = ({ size = 14, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Folder01Icon,
	size,
	...rest
});
/** The disclosure chevron; rotate it for open rows. */
var IconChevron = ({ size = 10, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: ArrowDown01Icon,
	size,
	...rest
});
/** Tree disclosure; the row rotates it when the folder is open. */
var IconCaret = ({ size = 10, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: ArrowRight01Icon,
	size,
	...rest
});
/** Close a drawer or a panel. */
var IconClose = ({ size = 12, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Cancel01Icon,
	size,
	...rest
});
/** The overflow "more" menu. */
var IconMore = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: MoreHorizontalIcon,
	size,
	...rest
});
/** Search. */
var IconSearch = ({ size = 15, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Search01Icon,
	size,
	...rest
});
/** The read-only chip's lock. */
var IconLock = ({ size = 12, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: SquareLock01Icon,
	size,
	...rest
});
/** The daemon is reachable — a live pulse. */
var IconPulse = ({ size = 12, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Pulse01Icon,
	size,
	...rest
});
/** The daemon is unreachable — a warning. */
var IconWarning = ({ size = 12, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Alert02Icon,
	size,
	...rest
});
/** Re-read the folders. */
var IconRefresh = ({ size = 12, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: RefreshIcon,
	size,
	...rest
});
/** Theme: follow the system. */
var IconTheme = ({ size = 14, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: ContrastIcon,
	size,
	...rest
});
/** Theme: light. */
var IconSun = ({ size = 14, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Sun01Icon,
	size,
	...rest
});
/** Theme: dark. */
var IconMoon = ({ size = 14, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Moon02Icon,
	size,
	...rest
});
/** Drop files into the wiki. */
var IconUpload = ({ size = 34, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Upload01Icon,
	size,
	...rest
});
/** A completed upload. */
var IconCheck = ({ size = 13, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Tick02Icon,
	size,
	...rest
});
/** Folder view: grid. */
var IconGrid = ({ size = 12, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: DashboardSquare01Icon,
	size,
	...rest
});
/** Folder view: list. */
var IconList = ({ size = 12, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: Menu01Icon,
	size,
	...rest
});
/** A newer UI version is available. */
var IconUpdate = ({ size = 18, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: CircleArrowUp01Icon,
	size,
	...rest
});
/** Daemon connection — paired plugs, distinct from activity and refresh. */
var IconConnection = ({ size = 18, ...rest } = {}) => /* @__PURE__ */ jsx(Glyph, {
	icon: ConnectIcon,
	size,
	...rest
});
function closedSelect() {
	return {
		open: false,
		active: -1,
		query: "",
		buffer: "",
		bufferAt: 0
	};
}
function showsSearch(options, searchable) {
	return searchable === true || options.length > 8;
}
function filterOptions(options, query) {
	const q = query.trim().toLowerCase();
	if (!q) return options.slice();
	return options.filter((option) => [
		option.label,
		option.hint,
		option.badge,
		option.value,
		option.group
	].some((part) => part?.toLowerCase().includes(q)));
}
/** Badge copy is ordinary text — a cost label, not an icon. */
function optionBadgeText(option) {
	const badge = option.badge?.trim();
	return badge ? badge : null;
}
function enabledIndexes(options) {
	const indexes = [];
	options.forEach((option, index) => {
		if (!option.disabled) indexes.push(index);
	});
	return indexes;
}
function canPick(option) {
	return option !== void 0 && !option.disabled;
}
function moveActive(options, active, key) {
	const enabled = enabledIndexes(options);
	if (enabled.length === 0) return -1;
	if (key === "Home") return enabled[0] ?? -1;
	if (key === "End") return enabled[enabled.length - 1] ?? -1;
	const pos = enabled.indexOf(active);
	if (key === "ArrowDown") {
		if (pos === -1) return enabled[0] ?? -1;
		return enabled[Math.min(pos + 1, enabled.length - 1)] ?? -1;
	}
	if (pos === -1) return enabled[enabled.length - 1] ?? -1;
	return enabled[Math.max(pos - 1, 0)] ?? -1;
}
/**
* Typeahead. A single new character starts after `from` and wraps. Extra
* characters inside the timeout extend the prefix and may stay on `from`.
* A disabled option is never a match. No match leaves `from` alone.
*/
function typeaheadIndex(options, buffer, from) {
	const q = buffer.trim().toLowerCase();
	if (!q) return from;
	const enabled = enabledIndexes(options);
	if (enabled.length === 0) return -1;
	const order = buffer.length > 1 ? [...enabled.filter((index) => index >= from), ...enabled.filter((index) => index < from)] : [...enabled.filter((index) => index > from), ...enabled.filter((index) => index <= from)];
	for (const index of order) {
		const option = options[index];
		if (!option) continue;
		if (option.label.toLowerCase().startsWith(q) || option.value.toLowerCase().startsWith(q)) return index;
	}
	return from;
}
function activeOnOpen(options, value) {
	const selected = options.findIndex((option) => option.value === value && !option.disabled);
	if (selected >= 0) return selected;
	return enabledIndexes(options)[0] ?? -1;
}
function openSelect(options, value) {
	return {
		open: true,
		active: activeOnOpen(options, value),
		query: "",
		buffer: "",
		bufferAt: 0
	};
}
var MOVE_KEYS = [
	"ArrowDown",
	"ArrowUp",
	"Home",
	"End"
];
function isMoveKey(key) {
	return MOVE_KEYS.includes(key);
}
function reduceSelectKey(model, options, searchOn, value, key, now, mods = {}) {
	const list = filterOptions(options, searchOn ? model.query : "");
	if (isMoveKey(key)) {
		if (!model.open) {
			const selected = list.findIndex((option) => option.value === value && !option.disabled);
			let active;
			if (key === "Home") active = moveActive(list, -1, "Home");
			else if (key === "End") active = moveActive(list, -1, "End");
			else if (key === "ArrowUp") active = selected >= 0 ? selected : moveActive(list, -1, "End");
			else active = selected >= 0 ? selected : enabledIndexes(list)[0] ?? -1;
			return {
				model: {
					...model,
					open: true,
					active,
					buffer: "",
					bufferAt: 0
				},
				pick: null,
				prevent: true
			};
		}
		return {
			model: {
				...model,
				active: moveActive(list, model.active, key)
			},
			pick: null,
			prevent: true
		};
	}
	if (key === "Escape") {
		if (!model.open) return {
			model,
			pick: null,
			prevent: false
		};
		return {
			model: closedSelect(),
			pick: null,
			prevent: true
		};
	}
	if (key === "Tab") {
		if (!model.open) return {
			model,
			pick: null,
			prevent: false
		};
		return {
			model: closedSelect(),
			pick: null,
			prevent: false
		};
	}
	if (key === "Enter" || key === " ") {
		if (!model.open) return {
			model: openSelect(list, value),
			pick: null,
			prevent: true
		};
		const option = list[model.active];
		if (!canPick(option)) return {
			model,
			pick: null,
			prevent: true
		};
		return {
			model: closedSelect(),
			pick: option.value,
			prevent: true
		};
	}
	if (key.length === 1 && !mods.meta && !mods.ctrl && !mods.alt && !searchOn) {
		const fresh = now - model.bufferAt > 500;
		const buffer = (fresh ? "" : model.buffer) + key;
		return {
			model: {
				open: true,
				active: typeaheadIndex(list, buffer, model.open && !fresh ? model.active : model.open ? model.active : -1),
				query: model.query,
				buffer,
				bufferAt: now
			},
			pick: null,
			prevent: true
		};
	}
	return {
		model,
		pick: null,
		prevent: false
	};
}
function reduceQuery(model, options, query, value) {
	const highlighted = filterOptions(options, model.query)[model.active];
	const list = filterOptions(options, query);
	const prefer = highlighted !== void 0 && list.some((option) => option.value === highlighted.value && !option.disabled) && highlighted ? highlighted.value : value;
	return {
		...model,
		open: true,
		query,
		active: activeOnOpen(list, prefer),
		buffer: "",
		bufferAt: 0
	};
}
function reduceOutside(model) {
	if (!model.open) return model;
	return closedSelect();
}
function reducePick(model, option) {
	if (!canPick(option)) return {
		model,
		pick: null,
		prevent: true
	};
	return {
		model: closedSelect(),
		pick: option.value,
		prevent: true
	};
}
/** Flip the popover above the trigger when the viewport bottom cannot hold it. */
function flipPlacement(trigger, popoverHeight, viewportHeight, gap = 4) {
	const spaceBelow = viewportHeight - trigger.bottom - gap;
	const spaceAbove = trigger.top - gap;
	if (spaceBelow < popoverHeight && spaceAbove > spaceBelow) return "above";
	return "below";
}
//#endregion
//#region ui/src/ui/Select.tsx
/**
* Select-only combobox: a button trigger plus a portaled listbox.
* Keyboard: Up/Down/Home/End move, Enter/Space pick, Escape closes,
* and a typed prefix jumps (unless the search field is showing).
*/
function Select({ value, onChange, options, placeholder, searchable, disabled, id, size = "md", full, className, title, ...rest }) {
	const t = useTranslate();
	const ariaLabel = rest["aria-label"];
	const reactId = useId();
	const base = id ?? reactId;
	const listId = `${base}-listbox`;
	const [model, setModel] = useState(closedSelect);
	const modelRef = useRef(model);
	modelRef.current = model;
	const triggerRef = useRef(null);
	const popRef = useRef(null);
	const searchRef = useRef(null);
	const keyClick = useRef(false);
	const restoreTrigger = useRef(false);
	const searchOn = showsSearch(options, searchable);
	const list = filterOptions(options, searchOn ? model.query : "");
	const selected = options.find((option) => option.value === value);
	const activeId = model.open && model.active >= 0 ? `${base}-opt-${model.active}` : void 0;
	const apply = (nextModel) => {
		modelRef.current = nextModel;
		setModel(nextModel);
	};
	const finish = (pick, nextModel, restore) => {
		const wasOpen = modelRef.current.open;
		apply(nextModel);
		if (pick !== null) onChange(pick);
		if (restore && wasOpen && !nextModel.open) restoreTrigger.current = true;
	};
	const onListKey = (event) => {
		if (disabled) return;
		const current = modelRef.current;
		const result = reduceSelectKey(current, options, searchOn, value, event.key, Date.now(), {
			meta: event.metaKey,
			ctrl: event.ctrlKey,
			alt: event.altKey
		});
		if (result.prevent) event.preventDefault();
		if (result.model !== current || result.pick !== null) {
			const closing = current.open && !result.model.open;
			finish(result.pick, result.model, closing && event.key !== "Tab");
		}
	};
	useLayoutEffect(() => {
		if (model.open || !restoreTrigger.current) return;
		restoreTrigger.current = false;
		triggerRef.current?.focus();
	}, [model.open]);
	useEffect(() => {
		if (!model.open) return;
		const onPointer = (event) => {
			const target = event.target;
			if (!(target instanceof Node)) return;
			if (triggerRef.current?.contains(target) || popRef.current?.contains(target)) return;
			finish(null, reduceOutside(modelRef.current), true);
		};
		document.addEventListener("pointerdown", onPointer);
		return () => document.removeEventListener("pointerdown", onPointer);
	}, [model.open]);
	useEffect(() => {
		if (!model.open || !searchOn) return;
		searchRef.current?.focus();
	}, [model.open, searchOn]);
	useEffect(() => {
		if (!model.open || model.active < 0) return;
		document.getElementById(`${base}-opt-${model.active}`)?.scrollIntoView({ block: "nearest" });
	}, [
		model.open,
		model.active,
		base
	]);
	useLayoutEffect(() => {
		if (!model.open) return;
		const place = () => {
			const trigger = triggerRef.current;
			const pop = popRef.current;
			if (!trigger || !pop) return;
			const rect = trigger.getBoundingClientRect();
			const gap = 4;
			const width = Math.min(Math.max(rect.width, 160), window.innerWidth - 16);
			const placement = flipPlacement(rect, pop.offsetHeight, window.innerHeight, gap);
			let left = rect.left;
			const maxLeft = window.innerWidth - width - 8;
			if (left > maxLeft) left = Math.max(8, maxLeft);
			const top = placement === "below" ? rect.bottom + gap : Math.max(8, rect.top - gap - pop.offsetHeight);
			pop.style.top = `${top}px`;
			pop.style.left = `${left}px`;
			pop.style.width = `${width}px`;
			pop.dataset.placement = placement;
		};
		place();
		window.addEventListener("resize", place);
		window.addEventListener("scroll", place, true);
		return () => {
			window.removeEventListener("resize", place);
			window.removeEventListener("scroll", place, true);
		};
	}, [
		model.open,
		model.query,
		list.length
	]);
	let lastGroup;
	const rows = [];
	list.forEach((option, index) => {
		if (option.group && option.group !== lastGroup) rows.push(/* @__PURE__ */ jsx("li", {
			role: "presentation",
			className: "select-group",
			children: option.group
		}, `group-${option.group}-${index}`));
		lastGroup = option.group;
		const badge = optionBadgeText(option);
		const active = index === model.active;
		rows.push(/* @__PURE__ */ jsxs("li", {
			id: `${base}-opt-${index}`,
			role: "option",
			"aria-selected": option.value === value,
			"aria-disabled": option.disabled || void 0,
			"data-active": active || void 0,
			className: "select-opt",
			onMouseEnter: () => {
				if (!option.disabled) apply({
					...modelRef.current,
					active: index
				});
			},
			onClick: () => {
				const result = reducePick(modelRef.current, option);
				finish(result.pick, result.model, result.pick !== null);
			},
			children: [
				/* @__PURE__ */ jsx("span", {
					className: "select-check",
					"aria-hidden": "true",
					children: option.value === value ? /* @__PURE__ */ jsx(IconCheck, { size: 12 }) : null
				}),
				/* @__PURE__ */ jsxs("span", {
					className: "select-copy",
					children: [/* @__PURE__ */ jsx("span", {
						className: "select-label",
						children: option.label
					}), option.hint ? /* @__PURE__ */ jsx("span", {
						className: "select-hint",
						children: option.hint
					}) : null]
				}),
				badge ? /* @__PURE__ */ jsx("span", {
					className: "select-badge",
					children: badge
				}) : null
			]
		}, `${option.value}-${index}`));
	});
	const pop = model.open && typeof document !== "undefined" ? createPortal(/* @__PURE__ */ jsxs("div", {
		className: "select-pop",
		ref: popRef,
		"data-placement": "below",
		children: [searchOn ? /* @__PURE__ */ jsx("input", {
			ref: searchRef,
			className: "select-search",
			value: model.query,
			placeholder: t("Search"),
			"aria-label": t("Search options"),
			"aria-controls": listId,
			"aria-activedescendant": activeId,
			onChange: (event) => apply(reduceQuery(modelRef.current, options, event.target.value, value)),
			onKeyDown: (event) => {
				if (event.key === "ArrowDown" || event.key === "ArrowUp" || event.key === "Home" || event.key === "End" || event.key === "Enter" || event.key === "Escape" || event.key === "Tab") onListKey(event);
			}
		}) : null, /* @__PURE__ */ jsx("ul", {
			id: listId,
			role: "listbox",
			"aria-label": ariaLabel,
			tabIndex: -1,
			className: "select-list",
			onKeyDown: onListKey,
			children: rows.length > 0 ? rows : /* @__PURE__ */ jsx("li", {
				role: "presentation",
				className: "select-empty",
				children: t("No matches")
			})
		})]
	}), triggerRef.current?.closest("dialog") ?? document.body) : null;
	return /* @__PURE__ */ jsxs("div", {
		className: [
			"select",
			size === "sm" ? "select-sm" : "",
			full ? "select-full" : "",
			className ?? ""
		].filter(Boolean).join(" "),
		children: [/* @__PURE__ */ jsxs("button", {
			ref: triggerRef,
			id,
			type: "button",
			className: "select-trigger",
			role: "combobox",
			"aria-haspopup": "listbox",
			"aria-expanded": model.open,
			"aria-controls": listId,
			"aria-activedescendant": activeId,
			"aria-label": ariaLabel,
			title,
			disabled,
			onClick: () => {
				if (keyClick.current) {
					keyClick.current = false;
					return;
				}
				if (disabled) return;
				if (modelRef.current.open) finish(null, closedSelect(), true);
				else apply(openSelect(options, value));
			},
			onKeyDown: (event) => {
				if (event.key === "Enter" || event.key === " ") {
					keyClick.current = true;
					setTimeout(() => {
						keyClick.current = false;
					}, 0);
				}
				onListKey(event);
			},
			children: [/* @__PURE__ */ jsx("span", {
				className: selected ? "select-value" : "select-value select-placeholder",
				children: selected?.label ?? placeholder ?? t("Select")
			}), /* @__PURE__ */ jsx(IconChevron, {
				size: 12,
				className: "select-caret"
			})]
		}), pop]
	});
}
//#endregion
//#region ui/src/lib/cache.ts
function message(e) {
	if (e && typeof e === "object" && "message" in e) return String(e.message);
	return String(e);
}
var Resource = class {
	state = {
		data: null,
		status: "loading",
		error: null,
		asOf: null,
		inFlight: false
	};
	inflight = null;
	trailing = false;
	/** Bumped by every local write; a fetch from an older one is dropped. */
	generation = 0;
	/** Invalidated while nobody watched: the next `revalidate` fetches. */
	invalid = false;
	listeners = /* @__PURE__ */ new Set();
	fetcher;
	isEmpty;
	freshMs;
	discardOnError;
	now;
	constructor(fetcher, opts = {}) {
		this.fetcher = fetcher;
		this.isEmpty = opts.isEmpty ?? (() => false);
		this.freshMs = opts.freshMs ?? 0;
		this.discardOnError = opts.discardOnError ?? (() => false);
		this.now = opts.now ?? Date.now;
	}
	/** Current snapshot. The object is replaced on every change. */
	get = () => this.state;
	subscribe = (listener) => {
		this.listeners.add(listener);
		return () => {
			this.listeners.delete(listener);
		};
	};
	/** Whether any component is subscribed. */
	observed = () => this.listeners.size > 0;
	/** Fetch now, or join the request already in flight. */
	refresh = () => this.refreshUsing(this.fetcher);
	/**
	* An explicit request variant, through the same state/error lifecycle.
	* The fetcher applies only to this run; revalidation and trailing loads
	* keep the default fetcher. Joins any request already in flight.
	*/
	refreshUsing = (fetcher) => {
		if (this.inflight) return this.inflight;
		this.invalid = false;
		const started = this.generation;
		this.set({
			inFlight: true,
			status: this.state.data === null ? "loading" : this.state.status
		});
		const run = fetcher().then((data) => {
			if (this.generation !== started) {
				this.trailing = true;
				return;
			}
			this.set({
				data,
				status: this.isEmpty(data) ? "empty" : "ok",
				error: null,
				asOf: this.now()
			});
		}, (e) => {
			if (this.generation !== started) return;
			const discard = this.discardOnError(e);
			this.set({
				data: discard ? null : this.state.data,
				asOf: discard ? null : this.state.asOf,
				status: discard || this.state.data === null ? "failed" : "stale",
				error: message(e)
			});
		});
		this.inflight = run.finally(() => {
			this.inflight = null;
			if (this.trailing) {
				this.trailing = false;
				this.refresh();
			} else this.set({ inFlight: false });
		});
		return this.inflight;
	};
	/**
	* The data changed on the server but nobody is looking: fetch on the
	* next `revalidate` (when a screen shows it) instead of now.
	*/
	markInvalid = () => {
		this.invalid = true;
	};
	/**
	* The data changed on the server. Fetch now; if a request is already in
	* flight it may predate the change, so queue one trailing request
	* (never more than one).
	*/
	invalidate = () => {
		if (this.inflight) {
			this.trailing = true;
			return this.inflight;
		}
		return this.refresh();
	};
	/**
	* Stale-while-revalidate: fetch unless the last success is younger than
	* `freshMs`. Joins a request in flight; never blanks loaded data.
	*/
	revalidate = () => {
		if (this.inflight) return this.inflight;
		const { asOf } = this.state;
		if (!this.invalid && asOf !== null && this.state.status !== "stale" && this.now() - asOf < this.freshMs) return Promise.resolve();
		return this.refresh();
	};
	/**
	* Replace the data from outside a fetch — a stream frame or a write
	* response that carries the whole value. Unlike `mutate` it also works
	* before the first load, and it counts as a fresh success.
	*/
	write = (fn) => {
		const data = fn(this.state.data);
		this.generation += 1;
		this.set({
			data,
			status: this.isEmpty(data) ? "empty" : "ok",
			error: null,
			asOf: this.now()
		});
	};
	/**
	* Apply an authoritative local change (a write response) to loaded data.
	* A no-op before the first load — the next fetch brings it.
	*/
	mutate = (fn) => {
		if (this.state.data === null) return;
		const data = fn(this.state.data);
		this.generation += 1;
		const status = this.isEmpty(data) ? "empty" : this.state.status === "stale" ? "stale" : "ok";
		this.set({
			data,
			status
		});
	};
	set(patch) {
		this.state = {
			...this.state,
			...patch
		};
		for (const listener of this.listeners) listener();
	}
};
/**
* Keyed stores: one `Resource` per key, created on first use and shared by
* every later caller. The fetcher and options of the first call win — a key
* names one server resource, so later callers would pass the same ones.
*/
var QueryCache = class {
	entries = /* @__PURE__ */ new Map();
	/** Family keys — per-argument stores that may be evicted when idle. */
	evictable = /* @__PURE__ */ new Set();
	maxIdle;
	/** `maxIdle`: family stores kept while nobody subscribes (oldest go first). */
	constructor(opts = {}) {
		this.maxIdle = opts.maxIdle ?? 32;
	}
	resource(key, fetcher, opts) {
		let entry = this.entries.get(key);
		if (!entry) entry = new Resource(fetcher, opts);
		this.entries.delete(key);
		this.entries.set(key, entry);
		return entry;
	}
	/** A family of keys under one prefix: `family("issue", api.issue)("CAD-1")`. */
	family(prefix, fetcher, opts) {
		return (arg) => {
			const key = `${prefix}:${arg}`;
			const entry = this.resource(key, () => fetcher(arg), opts);
			this.evictable.add(key);
			this.evict();
			return entry;
		};
	}
	/** The store for `key` if anything created it, else null. */
	peek(key) {
		return this.entries.get(key) ?? null;
	}
	/**
	* The data behind `key` (or every `key:…` family member) changed. Stores
	* a component is subscribed to refetch now; the others are only marked,
	* and refetch when a screen revalidates them — so invalidating a family
	* costs one request per store on screen, not one per id ever loaded.
	*/
	invalidate(key) {
		for (const [k, entry] of this.entries) {
			if (k !== key && !k.startsWith(`${key}:`)) continue;
			if (entry.observed()) entry.invalidate();
			else entry.markInvalid();
		}
	}
	/** Drop the least recently used idle family stores beyond `maxIdle`. */
	evict() {
		const idle = [...this.evictable].filter((k) => {
			const entry = this.entries.get(k);
			return entry && !entry.observed() && !entry.get().inFlight;
		});
		const order = [...this.entries.keys()];
		idle.sort((a, b) => order.indexOf(a) - order.indexOf(b));
		for (const k of idle.slice(0, Math.max(0, idle.length - this.maxIdle))) {
			this.entries.delete(k);
			this.evictable.delete(k);
		}
	}
};
//#endregion
//#region ui/src/lib/useResource.ts
/** Subscribe a component to one resource store. */
function useResource(resource) {
	return useSyncExternalStore(resource.subscribe, resource.get);
}
/**
* Subscribe and revalidate on mount (stale-while-revalidate): the screen
* paints whatever the store holds now — loading, or the last payload — and
* the store refetches behind it unless its data is still fresh.
*/
function useQuery(resource) {
	useEffect(() => {
		resource.revalidate();
	}, [resource]);
	return useResource(resource);
}
var noSubscribe = () => () => {};
var noState = () => null;
/** `useResource` for a store that may not exist (no drawer open). */
function useMaybeResource(resource) {
	return useSyncExternalStore(resource ? resource.subscribe : noSubscribe, resource ? resource.get : noState);
}
//#endregion
export { ApiError, Button, ConfirmDialog, DataTable, Detail, DrawerShell, EmptyState, ErrorNotice, Field, IconAgents, IconApps, IconCaret, IconCheck, IconChevron, IconClose, IconConnection, IconFolder, IconGrid, IconHome, IconList, IconLock, IconMoon, IconMore, IconOutbox, IconProjects, IconPulse, IconRefresh, IconSearch, IconSettings, IconSun, IconTheme, IconThreads, IconUpdate, IconUpload, IconWarning, IconWiki, Link, Loading, LocaleTextProvider, NavigationProvider, Notice, QueryCache, Resource, Select, useMaybeResource, useNavigation, useQuery, useResource };
